# -*- coding: utf-8 -*-
from django.shortcuts import render
from common.const import *
from PIL import Image
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt


def index(request):
    page_no = int(request.GET['no'])
    img_path = VALIDATION_DATA_PATH + 'candidate/val_%04d.png' % page_no
    loc_path = VALIDATION_DATA_PATH + 'candidate/val_%04d_loc.json' % page_no
    avlb_path = VALIDATION_DATA_PATH + 'candidate/val_%04d_available.json' % page_no
    avlb = None
    if os.path.exists(avlb_path):
        avlb = json.loads(open(avlb_path, 'r', encoding='utf8').read())
    img_conf = json.loads(open(loc_path, 'r', encoding='utf8').read())
    counter = 0
    for conf in img_conf:
        conf['location'] = (conf['location'][0] - 1, conf['location'][1] - 1, conf['location'][2] - conf['location'][0], conf['location'][3] - conf['location'][1])
        if avlb is None:
            conf['available'] = True
        else:
            conf['available'] = avlb[counter]
        conf['fontsize'] = min(conf['location'][2], conf['location'][3])
        conf['id'] = counter
        counter += 1
    if avlb is None:
        avlb = [True] * counter
        open(avlb_path, 'w', encoding='utf8').write(json.dumps(avlb))

    context = {
        'image_name': 'val_%04d.png' % page_no,
        'image': Image.open(img_path),
        'image_size': 100,
        'border_size': (60, 60),
        'image_conf': img_conf,
        'page_no': page_no
    }
    return render(request, 'index.html', context)


@csrf_exempt
def update(request):
    page_no = int(request.POST['page_no'])
    char_no = int(request.POST['char_id'])
    char_avlb = True if request.POST['available'] == 'true' else False
    avlb_path = VALIDATION_DATA_PATH + 'candidate/val_%04d_available.json' % page_no
    avlb = json.loads(open(avlb_path, 'r', encoding='utf8').read())
    avlb[char_no] = char_avlb
    open(avlb_path, 'w', encoding='utf8').write(json.dumps(avlb))
    return HttpResponse("Hello, world. You're at the polls index.")
