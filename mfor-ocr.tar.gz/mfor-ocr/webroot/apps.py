from django.apps import AppConfig


class WebrootConfig(AppConfig):
    name = 'webroot'
