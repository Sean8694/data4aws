# -*- coding: utf-8 -*-
from common.const import *


class DataLoader(object):

    def __init__(self):
        self._char_list = None
        self._id_char_mapping = None
        self._char_id_mapping = None
        self._symbol_list = None

    @property
    def char_list(self):
        if isinstance(self._char_list, list):
            return self._char_list
        self._char_list = list()
        with open(CHAR_PATH, 'r', encoding='utf8') as f:
            for line in f.readlines():
                self._char_list.append(line.strip())
        return self._char_list

    @property
    def id_char_mapping(self):
        if isinstance(self._id_char_mapping, dict):
            return self._id_char_mapping
        counter = 0
        self._id_char_mapping = dict()
        for char in self.char_list:
            counter += 1
            self._id_char_mapping[counter] = char
        return self._id_char_mapping

    @property
    def char_id_mapping(self):
        if isinstance(self._char_id_mapping, dict):
            return self._char_id_mapping
        counter = 0
        self._char_id_mapping = dict()
        for char in self.char_list:
            counter += 1
            self._char_id_mapping[char] = counter
        return self._char_id_mapping

    @property
    def symbol_list(self):
        if isinstance(self._symbol_list, list):
            return self._symbol_list
        self._symbol_list = list()
        with open(SYMBOL_PATH, 'r', encoding='utf8') as f:
            for line in f.readlines():
                self._symbol_list.append(line.strip())
        return self._symbol_list

dl = DataLoader()


def get_id_char_mapping():
    return dl.id_char_mapping


def get_char_id_mapping():
    return dl.char_id_mapping


def get_symbol_list():
    return dl.symbol_list

if __name__ == '__main__':
    print(get_id_char_mapping())
    print(get_char_id_mapping())
    print(get_symbol_list())
