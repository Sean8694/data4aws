# -*- coding: utf-8 -*-
from common.const import *
import os
import json

total_string = ''

for img_no in range(1, 51):
    rec_path = TESTING_DATA_PATH + 'image_%d_rec.json' % img_no
    if not os.path.exists(rec_path):
        continue
    conf = json.loads(''.join(open(rec_path, 'r', encoding='utf8').readlines()))
    total_string += ''.join([x['words'] for x in conf['words_result']])

str_list = list(total_string)
wf_dict = dict()
for w in set(str_list):
    wf_dict[w] = str_list.count(w)

open(CHAR_FREQ_PATH, 'w', encoding='utf8').write(json.dumps(wf_dict))
