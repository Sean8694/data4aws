# -*- coding: utf-8 -*-
from aip import AipOcr
from common.const import *
import os
import json


# 定义常量
APP_ID = '9301045'
API_KEY = 'fGnviX7YX891xdT5krggamWs'
SECRET_KEY = 'c6Nfp2HyyYhDxBtnR0ytBwvBqvq8a60E'


# 读取图片
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()


# 初始化ApiOcr对象
aipOcr = AipOcr(APP_ID, API_KEY, SECRET_KEY)

for img_no in range(1, 51):
    rec_path = TESTING_DATA_PATH + 'image_%d_rec.json' % img_no
    if os.path.exists(rec_path):
        continue
    img_path = TESTING_DATA_PATH + 'image_%d_gray.png' % img_no
    # 调用通用文字识别接口
    result = aipOcr.general(get_file_content(img_path), {'recognize_granularity': 'small'})
    open(rec_path, 'w', encoding='utf8').write(json.dumps(result))
