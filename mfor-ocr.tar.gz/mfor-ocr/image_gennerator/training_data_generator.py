# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from math import floor, ceil
from data.loader import get_char_id_mapping, get_id_char_mapping, get_symbol_list
from common.const import *
import numpy
import random
import json
from multiprocessing.pool import Pool
import multiprocessing


mlock = multiprocessing.Lock()

class TrainingDataGenerator(object):

    def __init__(self):
        self.symbol_ratio = 1.0
        self.font_size_range = range(24, 29, 2)
        self.symbol_size_range = range(20, 29, 1)

    def square_image(self, image):
        size = max(image.size)
        image_resized = Image.new('L', (size, size), 255)
        image_resized.paste(image, (floor((size - image.size[0]) / 2), floor((size - image.size[1]) / 2)))
        return image_resized

    def standard_image(self, image):
        image_resized = Image.new('L', (STANDARD_FONT_SIZE, STANDARD_FONT_SIZE), 255)
        image_resized.paste(image, (floor((STANDARD_FONT_SIZE - image.size[0]) / 2), floor((STANDARD_FONT_SIZE - image.size[1]) / 2)))
        return image_resized

    def blur_image_list(self, char_image_list, radius):
        blur_image_list = [image.filter(ImageFilter.GaussianBlur(radius)) for image in char_image_list]
        return blur_image_list

    def rotate_image_list(self, char_image_list, angle):
        ny_char_image_list = [numpy.array(char_image) for char_image in char_image_list]
        ny_char_image_list = [255 - ny_char_image for ny_char_image in ny_char_image_list]
        image_list = list()
        for ny_char_image in ny_char_image_list:
            char_image = Image.fromarray(ny_char_image, 'L')
            for agl in range(-angle, angle + 1):
                image_rotate = char_image.rotate(agl, expand=1)
                nyimg = numpy.array(image_rotate)
                nyimg = 255 - nyimg
                image_list.append(Image.fromarray(nyimg, 'L'))
        return image_list

    def cut_image_list(self, char_image_list, cut_off):
        image_list = list()
        for image in char_image_list:
            for cut_x in range(-cut_off, cut_off + 1):
                for cut_y in range(-cut_off, cut_off + 1):
                    box = (max(cut_x, 0),
                           max(cut_y, 0),
                           min(image.size[0], image.size[0] + cut_x),
                           min(image.size[1], image.size[1] + cut_y))
                    img_cut = image.crop(box)
                    image_list.append(img_cut)
        return image_list

    def stretch_image_list(self, char_image_list, max_size):
        image_list = list()
        for image in char_image_list:
            image_list.append(image)
            for width in range(image.size[0] + 1, max_size + 1):
                image_list.append(image.resize((width, image.size[1])))
            for height in range(image.size[1] + 1, max_size + 1):
                image_list.append(image.resize((image.size[0], height)))
        return image_list

    def shift_image_list(self, char_image_list, size):
        image_list = list()
        for image in char_image_list:
            room_x = size - image.size[0]
            room_y = size - image.size[1]
            for offset_x in range(room_x + 1):
                for offset_y in range(room_y + 1):
                    standard_img = Image.new('L', (size, size), color=255)
                    standard_img.paste(image, box=(offset_x, offset_y))
                    image_list.append(standard_img)
        return image_list

    def generate_basic_char_image(self, char, fontsize):
        image_font = ImageFont.truetype(FONT_PATH, fontsize)
        image = Image.new('L', (fontsize * 2, fontsize * 2), 255)
        dr = ImageDraw.Draw(image)
        dr.text((1, 1), char, font=image_font, fill='#000000')
        np_im = numpy.array(image)
        x_mean = np_im.mean(0)
        y_mean = np_im.mean(1)
        box = [0, 0, 0, 0]
        for val in x_mean:
            if val == 255 and box[2] == 0:
                box[0] += 1
            elif val != 255 and box[2] == 0:
                box[2] = box[0]
            elif val != 255 and box[2] != 0:
                box[2] += 1
            elif val == 255 and box[2] != 0:
                box[2] += 1
                break
        for val in y_mean:
            if val == 255 and box[3] == 0:
                box[1] += 1
            elif val != 255 and box[3] == 0:
                box[3] = box[1]
            elif val != 255 and box[3] != 0:
                box[3] += 1
            elif val == 255 and box[3] != 0:
                box[3] += 1
                break
        if box[2] - box[0] > box[3] - box[1]:
            box[1] -= floor((box[2] - box[0] - box[3] + box[1]) / 2)
            box[3] = box[1] + box[2] - box[0]
        elif box[2] - box[0] < box[3] - box[1]:
            box[0] -= floor((box[3] - box[1] - box[2] + box[0]) / 2)
            box[2] = box[0] + box[3] - box[1]
        im_crop = image.crop(tuple(box))
        return self.square_image(im_crop)

    def generate_basic_symbol_image(self, symbol, fontsize):
        image_font = ImageFont.truetype(FONT_PATH, fontsize)
        image = Image.new('L', (fontsize * 2, fontsize), 255)
        dr = ImageDraw.Draw(image)
        dr.text((1, -floor(fontsize * 0.2)), symbol, font=image_font, fill='#000000')
        np_im = numpy.array(image)
        x_mean = np_im.mean(0)
        box = [0, 0, 0, fontsize]
        for val in x_mean:
            if val == 255 and box[2] == 0:
                box[0] += 1
            elif val != 255 and box[2] == 0:
                box[2] = box[0]
            elif val != 255 and box[2] != 0:
                box[2] += 1
            elif val == 255 and box[2] != 0:
                box[2] += 1
                break
        im_crop = image.crop(tuple(box))
        return self.square_image(im_crop)

    def generate_variant_char_image_list(self, char):
        rotate_angle = 10
        cut_off_pixel = 1
        # 基础图像
        char_image_list = [self.generate_basic_char_image(char, font_size) for font_size in self.font_size_range]
        # channel1 旋转 -> 切边 -> 拉伸
        channel1 = self.rotate_image_list(char_image_list, rotate_angle)
        channel1 = self.cut_image_list(channel1, cut_off_pixel)
        channel1 = self.stretch_image_list(channel1, STANDARD_FONT_SIZE)
        # channel2 切边 -> 旋转 -> 拉伸
        channel2 = self.cut_image_list(char_image_list, cut_off_pixel)
        channel2 = self.rotate_image_list(channel2, rotate_angle)
        channel2 = self.stretch_image_list(channel2, STANDARD_FONT_SIZE)
        # channel3 切边 -> 拉伸 -> 旋转
        channel3 = self.cut_image_list(char_image_list, cut_off_pixel)
        channel3 = self.rotate_image_list(channel3, rotate_angle)
        channel3 = self.stretch_image_list(channel3, STANDARD_FONT_SIZE)
        # 合并
        char_image_list.extend(channel1)
        char_image_list.extend(channel2)
        char_image_list.extend(channel3)
        # 平移处理
        char_image_list = self.shift_image_list(char_image_list, STANDARD_FONT_SIZE)
        # 模糊处理
        char_image_list = self.blur_image_list(char_image_list, 1)
        # 随机排序
        random.shuffle(char_image_list)
        return char_image_list

    def generate_candidate_char_image_list_file(self, char, idx, set_size):
        char_image_list = self.generate_variant_char_image_list(char)
        char_image_list = char_image_list[:TRAINING_CHAR_SET_MAX_BATCH * set_size]
        counter = 0
        char_pool = True
        while char_pool:
            if len(char_image_list) < set_size:
                char_pool = False
                continue
            x = char_image_list[:set_size]
            char_image_list = char_image_list[set_size:]
            x = numpy.array([numpy.array(im, dtype=numpy.uint8) for im in x], dtype=numpy.uint8)
            x = x.reshape((x.size, ))
            y = numpy.array([idx] * set_size, dtype=numpy.uint8)
            with mlock:
                open(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % counter, 'ba').write(x.tobytes())
                open(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % counter, 'ba').write(y.tobytes())
            counter += 1
        return counter

    def restructuring_training_image_files(self, idx):
        x = open(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % idx, 'rb').read()
        x = numpy.fromstring(x, dtype=numpy.uint8)
        x = x.reshape((int(x.size / (STANDARD_FONT_SIZE * STANDARD_FONT_SIZE)), STANDARD_FONT_SIZE, STANDARD_FONT_SIZE))
        numpy.save(TRAINING_DATA_PATH + 'x_%04d.npy' % idx, x)
        y = open(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % idx, 'rb').read()
        y = numpy.fromstring(y, dtype=numpy.uint8)
        numpy.save(TRAINING_DATA_PATH + 'y_%04d.npy' % idx, y)

    def generate_training_char_image_files(self):
        # 加载参数
        char_id_mapping = get_char_id_mapping()
        id_char_mapping = get_id_char_mapping()

        # 加载词频
        print('load char frequency info.')
        char_freq = json.loads(open(DATA_PATH + 'char_freq.json', 'r', encoding='utf8').read())
        max_char_freq = max(char_freq.values())
        char_count_mapping = dict()
        for char in char_id_mapping:
            freq = char_freq[char] if char in char_freq else 0
            count_append = ceil((freq / max_char_freq) * (TRAINING_CHAR_SET_SIZE - TRAINING_CHAR_SET_MIN))
            char_count_mapping[char] = TRAINING_CHAR_SET_MIN + count_append
        char_count_list = [char_count_mapping[id_char_mapping[idx]] for idx in range(1, len(get_id_char_mapping()) + 1)]

        # 生成图片
        print('generating char images.')
        if os.path.exists(TRAINING_DATA_PATH + 'candidate'):
            os.system('rm -rf ' + TRAINING_DATA_PATH + 'candidate')
        os.mkdir(TRAINING_DATA_PATH + 'candidate')
        with Pool(ceil(multiprocessing.cpu_count() * 0.7)) as p:
            asy_rst = list()
            for idx in range(1, len(id_char_mapping) + 1):
                asy_rst.append(p.apply_async(func=self.generate_candidate_char_image_list_file,
                                             kwds={
                                                 'char': id_char_mapping[idx],
                                                 'idx': idx,
                                                 'set_size': char_count_list[idx - 1]
                                             }))
            batch_mx = 0
            batch_num = 9999999999
            counter = 0
            for rst in asy_rst:
                batch_mx = max(batch_mx, rst.get())
                batch_num = min(batch_num, rst.get())
                counter += 1
                if counter % floor(len(id_char_mapping) / 100) == 0:
                    print('%d / %d' % (counter, len(id_char_mapping)))

        # 删除多余文件
        print('deleting useless char images.')
        for idx in range(batch_num, batch_mx):
            if os.path.exists(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % idx):
                os.remove(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % idx)
            if os.path.exists(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % idx):
                os.remove(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % idx)

        # 重组文件
        print('restructuring char images.')
        with Pool(ceil(multiprocessing.cpu_count() * 0.7)) as p:
            asy_rst = list()
            counter = 0
            for idx in range(batch_num):
                asy_rst.append(p.apply_async(self.restructuring_training_image_files, kwds={'idx': idx}))
            for rst in asy_rst:
                rst.wait()
                counter += 1
                print('%d/%d' % (counter, batch_num))


    # def generate_training_symbol_image_list(self):
    #     sym = list()
    #     for symbol in get_symbol_list():
    #         symbol_image_list = list()
    #         for font_size in self.symbol_size_range:
    #             symbol_image_list.append(self.generate_basic_symbol_image(symbol, font_size))
    #         cut_image_list = list()
    #         for im in symbol_image_list:
    #             cut_image_list.extend(self.generate_cutted_images(im, 1))
    #         images = list()
    #         for im in cut_image_list:
    #             images.extend(self.generate_shifted_images(im, STANDARD_FONT_SIZE))
    #         blured_images = self.blur_images(images, 1)
    #         images.extend(blured_images)
    #         random.shuffle(images)
    #         sym.extend([numpy.array(im) for im in images])
    #     random.shuffle(sym)
    #     print('num of image symbols: %d' % len(sym))

if __name__ == '__main__':
    tdg = TrainingDataGenerator()
    tdg.generate_training_char_image_files()
