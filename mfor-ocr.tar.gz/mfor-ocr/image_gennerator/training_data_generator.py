# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from math import floor, ceil
from data.loader import get_char_id_mapping, get_id_char_mapping, get_symbol_list
from common.const import *
import numpy
import random
import json
from multiprocessing.pool import Pool
import multiprocessing


class TrainingDataGenerator(object):

    def __init__(self):
        self.symbol_ratio = 1.0
        self.font_size_range = range(24, 28, 2)
        self.symbol_size_range = range(20, 28, 1)

    def square_image(self, image):
        size = max(image.size)
        image_resized = Image.new('L', (size, size), 255)
        image_resized.paste(image, (floor((size - image.size[0]) / 2), floor((size - image.size[1]) / 2)))
        return image_resized

    def standard_image(self, image):
        image_resized = Image.new('L', (STANDARD_FONT_SIZE, STANDARD_FONT_SIZE), 255)
        image_resized.paste(image, (floor((STANDARD_FONT_SIZE - image.size[0]) / 2), floor((STANDARD_FONT_SIZE - image.size[1]) / 2)))
        return image_resized

    def blur_image(self, image, radius):
        image_blur = image.filter(ImageFilter.GaussianBlur(radius))
        return image_blur

    def rotate_image_list(self, image, angle):
        image_list = list()
        nyimg = numpy.array(image)
        nyimg = 255 - nyimg
        image = Image.fromarray(nyimg, 'L')
        for agl in range(-angle, angle + 1):
            if agl == 0:
                continue
            image_rotate = image.rotate(agl, expand=1)
            nyimg = numpy.array(image_rotate)
            nyimg = 255 - nyimg
            image_list.append(Image.fromarray(nyimg, 'L'))
        return image_list

    def cut_image_list(self, image, cut_off):
        image_list = list()
        for cut_x in range(-cut_off, cut_off + 1):
            for cut_y in range(-cut_off, cut_off + 1):
                if cut_x == 0 and cut_y == 0:
                    continue
                box = (max(cut_x, 0),
                       max(cut_y, 0),
                       min(image.size[0], image.size[0] + cut_x),
                       min(image.size[1], image.size[1] + cut_y))
                img_cut = image.crop(box)
                image_list.append(img_cut)
        return image_list

    def stretch_image_list(self, image, max_size):
        image_list = list()
        for width in range(image.size[0] + 1, max_size + 1):
            image_list.append(image.resize((width, image.size[1])))
        for height in range(image.size[1] + 1, max_size + 1):
            image_list.append(image.resize((image.size[0], height)))
        return image_list

    def shift_image_list(self, image, size):
        room_x = size - image.size[0]
        room_y = size - image.size[1]
        image_list = list()
        for offset_x in range(room_x + 1):
            for offset_y in range(room_y + 1):
                standard_img = Image.new('L', (size, size), color=255)
                standard_img.paste(image, box=(offset_x, offset_y))
                image_list.append(standard_img)
        return image_list

    def generate_basic_char_image(self, char, fontsize):
        image_font = ImageFont.truetype(FONT_PATH, fontsize)
        image = Image.new('L', (fontsize * 2, fontsize * 2), 255)
        dr = ImageDraw.Draw(image)
        dr.text((1, 1), char, font=image_font, fill='#000000')
        np_im = numpy.array(image)
        x_mean = np_im.mean(0)
        y_mean = np_im.mean(1)
        box = [0, 0, 0, 0]
        for val in x_mean:
            if val == 255 and box[2] == 0:
                box[0] += 1
            elif val != 255 and box[2] == 0:
                box[2] = box[0]
            elif val != 255 and box[2] != 0:
                box[2] += 1
            elif val == 255 and box[2] != 0:
                box[2] += 1
                break
        for val in y_mean:
            if val == 255 and box[3] == 0:
                box[1] += 1
            elif val != 255 and box[3] == 0:
                box[3] = box[1]
            elif val != 255 and box[3] != 0:
                box[3] += 1
            elif val == 255 and box[3] != 0:
                box[3] += 1
                break
        if box[2] - box[0] > box[3] - box[1]:
            box[1] -= floor((box[2] - box[0] - box[3] + box[1]) / 2)
            box[3] = box[1] + box[2] - box[0]
        elif box[2] - box[0] < box[3] - box[1]:
            box[0] -= floor((box[3] - box[1] - box[2] + box[0]) / 2)
            box[2] = box[0] + box[3] - box[1]
        im_crop = image.crop(tuple(box))
        return self.square_image(im_crop)

    def generate_basic_symbol_image(self, symbol, fontsize):
        image_font = ImageFont.truetype(FONT_PATH, fontsize)
        image = Image.new('L', (fontsize * 2, fontsize), 255)
        dr = ImageDraw.Draw(image)
        dr.text((1, -floor(fontsize * 0.2)), symbol, font=image_font, fill='#000000')
        np_im = numpy.array(image)
        x_mean = np_im.mean(0)
        box = [0, 0, 0, fontsize]
        for val in x_mean:
            if val == 255 and box[2] == 0:
                box[0] += 1
            elif val != 255 and box[2] == 0:
                box[2] = box[0]
            elif val != 255 and box[2] != 0:
                box[2] += 1
            elif val == 255 and box[2] != 0:
                box[2] += 1
                break
        im_crop = image.crop(tuple(box))
        return self.square_image(im_crop)

    def generate_variant_char_image_list(self, char, idx):
        char_image_list = [self.generate_basic_char_image(char, font_size) for font_size in self.font_size_range]
        # 旋转处理
        rotate_image_list = [self.rotate_image_list(image, 10) for image in char_image_list]
        rotate_image_list = [img for img_list in rotate_image_list for img in img_list]
        char_image_list.extend(rotate_image_list)
        # 切边处理
        cut_image_list = [self.cut_image_list(char_image, 1) for char_image in char_image_list]
        cut_image_list = [img for img_list in cut_image_list for img in img_list]
        char_image_list.extend(cut_image_list)
        # 拉伸处理
        strech_image_list = [self.stretch_image_list(char_image, STANDARD_FONT_SIZE) for char_image in char_image_list]
        strech_image_list = [img for img_list in strech_image_list for img in img_list]
        char_image_list.extend(strech_image_list)
        # 平移处理
        shift_image_list = [self.shift_image_list(char_image, STANDARD_FONT_SIZE) for char_image in char_image_list]
        shift_image_list = [img for img_list in shift_image_list for img in img_list]
        char_image_list = shift_image_list
        # 模糊处理
        blur_image_list = [self.blur_image(char_image, 1) for char_image in char_image_list]
        char_image_list = blur_image_list
        # 随机排序
        random.shuffle(char_image_list)
        # 序列化
        ny_ary_x = numpy.array([numpy.array(im) for im in char_image_list])
        ny_ary_y = numpy.array([idx] * len(char_image_list))
        numpy.save(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % idx, ny_ary_x)
        numpy.save(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % idx, ny_ary_y)
        return len(char_image_list)

    def generate_training_char_image_matrix(self):
        id_char_mapping = get_id_char_mapping()
        with Pool(ceil(multiprocessing.cpu_count() * 0.7)) as p:
            asy_rst = list()
            for idx in range(1, len(id_char_mapping) + 1):
                asy_rst.append(p.apply_async(func=self.generate_variant_char_image_list, kwds={'char': id_char_mapping[idx], 'idx': idx}))
            counter = 0
            char_set_max = 0
            char_set_min = 9999999999
            for rst in asy_rst:
                if max(char_set_max, rst.get()) > char_set_max or min(char_set_min, rst.get()) < char_set_min:
                    char_set_max = max(char_set_max, rst.get())
                    char_set_min = min(char_set_min, rst.get())
                    print('char set count: (%d, %d)' % (char_set_min, char_set_max))
                counter += 1
                if counter % floor(len(asy_rst) / 100) == 0:
                    print('%d / %d' % (counter, len(asy_rst)))

    # def generate_training_symbol_image_list(self):
    #     sym = list()
    #     for symbol in get_symbol_list():
    #         symbol_image_list = list()
    #         for font_size in self.symbol_size_range:
    #             symbol_image_list.append(self.generate_basic_symbol_image(symbol, font_size))
    #         cut_image_list = list()
    #         for im in symbol_image_list:
    #             cut_image_list.extend(self.generate_cutted_images(im, 1))
    #         images = list()
    #         for im in cut_image_list:
    #             images.extend(self.generate_shifted_images(im, STANDARD_FONT_SIZE))
    #         blured_images = self.blur_images(images, 1)
    #         images.extend(blured_images)
    #         random.shuffle(images)
    #         sym.extend([numpy.array(im) for im in images])
    #     random.shuffle(sym)
    #     print('num of image symbols: %d' % len(sym))

    def generate_training_images(self):
        print('load char frequency info.')
        char_freq = json.loads(open(DATA_PATH + 'char_freq.json', 'r', encoding='utf8').read())
        char_id_mapping = get_char_id_mapping()
        id_char_mapping = get_id_char_mapping()
        char_freq_mapping = {char: (char_freq[char] + 10) if char in char_freq else 10 for char in char_id_mapping}
        char_count_mapping = {char: ceil(numpy.log10(char_freq_mapping[char]) / numpy.log10(max(char_freq_mapping.values())) * TRAINING_CHAR_SET_SIZE) for char in char_freq_mapping}
        char_count_list = [char_count_mapping[id_char_mapping[idx]] for idx in range(1, len(get_id_char_mapping()) + 1)]

        print('generate char image.')
        self.generate_training_char_image_matrix()

        counter = 0
        char_pool = True
        while char_pool:
            training_x = list()
            training_y = list()
            for char_idx in range(1, len(id_char_mapping) + 1):
                x_train = numpy.load(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % char_idx)
                y_train = numpy.load(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % char_idx)
                char_set_length = char_count_list[char_idx - 1]
                if len(x_train) < char_set_length:
                    char_pool = False
                    break
                training_x.extend(x_train[:char_set_length])
                x_train = x_train[char_set_length:]
                training_y.extend(y_train[:char_set_length])
                y_train = y_train[char_set_length:]
                numpy.save(TRAINING_DATA_PATH + 'candidate/x_%04d.npy' % char_idx, x_train)
                numpy.save(TRAINING_DATA_PATH + 'candidate/y_%04d.npy' % char_idx, y_train)

            if not char_pool:
                continue
            training_x = numpy.array(training_x)
            print(training_x.shape)
            numpy.save(TRAINING_DATA_PATH + 'x_%04d.npy' % counter, training_x)
            training_y = numpy.array(training_y)
            print(training_y.shape)
            numpy.save(TRAINING_DATA_PATH + 'y_%04d.npy' % counter, training_y)
            counter += 1


if __name__ == '__main__':
    tdg = TrainingDataGenerator()
    tdg.generate_training_images()
