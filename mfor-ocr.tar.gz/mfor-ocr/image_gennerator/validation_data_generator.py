# -*- coding: utf-8 -*-
from PIL import Image
from common.const import *
import json
import numpy
from data.loader import get_char_id_mapping
import os
from image_processor.processor import ImageProcessor


class ValidationDataGenerator(object):

    def __init__(self):
        self._img_proc = ImageProcessor()
        self._img_no_range = range(1, 51)

    def image_conf_paths(self, img_no):
        return (VALIDATION_DATA_PATH + 'candidate/val_%04d.png' % img_no,
                VALIDATION_DATA_PATH + 'candidate/val_%04d_ptx.json' % img_no,
                VALIDATION_DATA_PATH + 'candidate/val_%04d_bd.json' % img_no,
                VALIDATION_DATA_PATH + 'candidate/val_%04d_loc.json' % img_no,
                VALIDATION_DATA_PATH + 'candidate/val_%04d_available.json' % img_no)

    def intersection_ratio(self, b1, b2):
        int_w = max(min(b1[2], b2[2]) - max(b1[0], b2[0]), 0)
        int_h = max(min(b1[3], b2[3]) - max(b1[1], b2[1]), 0)
        int_area = int_w * int_h
        area1 = (b1[2] - b1[0]) * (b1[3] - b1[1])
        area2 = (b2[2] - b2[0]) * (b2[3] - b2[1])
        return min(int_area / area1, int_area / area2)

    def generate_image_ocr_conf(self, img_no):
        img_path, img_ptx_path, img_bd_path, img_loc_path, _ = self.image_conf_paths(img_no)
        if not os.path.exists(img_ptx_path):
            # TODO
            pass
        if not os.path.exists(img_bd_path):
            result = self._img_proc.baidu_ocr(img_path)
            open(img_bd_path, 'w', encoding='utf8').write(json.dumps(result))
        if not os.path.exists(img_loc_path):
            ptx_conf = json.loads(open(img_ptx_path, 'r', encoding='utf8').read())
            bd_conf = json.loads(open(img_bd_path, 'r', encoding='utf8').read())
            boxes = list()
            loc_conf = list()
            for blk in ptx_conf['blocks']:
                for c in blk['chars']:
                    bd_box = (blk['x'] + c[0], blk['y'] + c[1], blk['x'] + c[0] + c[2], blk['y'] + c[1] + c[3])
                    boxes.append(bd_box)

            for blk in bd_conf['words_result']:
                for c in blk['chars']:
                    loc = c['location']
                    char = c['char']
                    bd_box = (loc['left'], loc['top'], loc['left'] + loc['width'], loc['top'] + loc['height'])
                    for ptx_box in boxes:
                        if self.intersection_ratio(ptx_box, bd_box) > 0.5:
                            loc_conf.append(
                                {
                                    'location': ptx_box,
                                    'char': char
                                }
                            )
                            break
            open(img_loc_path, 'w', encoding='utf8').write(json.dumps(loc_conf))

    def generate_all_image_loc_conf(self):
        for img_no in self._img_no_range:
            self.generate_image_ocr_conf(img_no)

    def generate_validation_data(self):
        char_id_mapping = get_char_id_mapping()
        x = list()
        y = list()
        for img_no in self._img_no_range:
            img_path, _, _, img_loc_path, img_available_path = self.image_conf_paths(img_no)
            if not os.path.exists(img_path)\
                or not os.path.exists(img_loc_path)\
                or not os.path.exists(img_available_path):
                continue
            img = Image.open(img_path)
            loc_conf = json.loads(open(img_loc_path, 'r', encoding='utf8').read())
            available_conf = json.loads(open(img_available_path, 'r', encoding='utf8').read())
            for idx in range(len(loc_conf)):
                if available_conf[idx] is False:
                    continue
                location = loc_conf[idx]['location']
                char = loc_conf[idx]['char']
                if char not in char_id_mapping:
                    continue
                img_crop = img.crop(tuple(location))
                img_ny = numpy.array(self._img_proc.normalize_image(img_crop))
                char_id = char_id_mapping[char] if char in char_id_mapping else 0
                x.append(img_ny)
                y.append(char_id)
        x = numpy.array(x)
        y = numpy.array(y)
        print('x shape: ' + str(x.shape))
        print('y shape: ' + str(y.shape))
        numpy.save(VALIDATION_DATA_PATH + 'x.npy', x)
        numpy.save(VALIDATION_DATA_PATH + 'y.npy', y)


if __name__ == '__main__':
    vdg = ValidationDataGenerator()
    vdg.generate_validation_data()
