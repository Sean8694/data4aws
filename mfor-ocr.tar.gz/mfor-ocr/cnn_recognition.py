# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont
import math
import numpy
import json
from keras.models import model_from_json
from common.const import *
from data.loader import *


def recognize_images(images):
    id_char_mapping = get_id_char_mapping()
    test_x_list = list()

    for image in images:
        width = image.size[0]
        height = image.size[1]
        size = (math.ceil(STANDARD_FONT_SIZE * width / max(width, height)), math.ceil(STANDARD_FONT_SIZE * height / max(width, height)))

        img_resized = image.resize(size, Image.ANTIALIAS)
        img_standard = Image.new('L', (STANDARD_FONT_SIZE, STANDARD_FONT_SIZE), color=255)
        img_standard.paste(img_resized, box=(math.floor((STANDARD_FONT_SIZE - size[0]) / 2), math.floor((STANDARD_FONT_SIZE - size[1]) / 2)))

        array = numpy.array(img_standard)
        array = array.astype('float32')
        array /= 255
        test_x_list.append(array)
    x = numpy.array(test_x_list)
    model = model_from_json(open(MODEL_ARCH_PATH).read())
    model.load_weights(MODEL_WEIGHTS_PATH)

    # preds = model.predict_classes(x[:, :, :, numpy.newaxis])
    # return [id_char_mapping[x if x != 0 else 10] for x in preds]
    preds = model.predict(x[:, :, :, numpy.newaxis])
    pred_idxs = list()
    for pred in preds:
        idxs = pred.argsort()[-5:][::-1]
        pred_idxs.append([(id_char_mapping[x] if x != 0 else 'x', pred[x]) for x in idxs])
    return pred_idxs

img_no = 1
file_path = TESTING_DATA_PATH + 'image_%d_gray.png' % img_no
conf_path = TESTING_DATA_PATH + 'image_%d.json' % img_no

with open(conf_path, 'r', encoding='utf8') as f:
    json_string = f.read()
    conf_json = json.loads(json_string)

testing_img = Image.open(file_path)
output_img = Image.new('RGB', testing_img.size, (255, 255, 255))
output_img.paste(testing_img, (0, 0) + testing_img.size)
im_draw = ImageDraw.Draw(output_img)

images = list()
for blk in conf_json['blocks']:
    for c in blk['chars']:
        box = (blk['x'] + c[0], blk['y'] + c[1], blk['x'] + c[0] + c[2], blk['y'] + c[1] + c[3])
        img_crop = testing_img.crop(box)
        images.append(img_crop)

recogs = recognize_images(images)

counter = 0
for blk in conf_json['blocks']:
    for c in blk['chars']:
        char = recogs[counter][0][0]
        counter += 1
        box = (blk['x'] + c[0], blk['y'] + c[1], blk['x'] + c[0] + c[2], blk['y'] + c[1] + c[3])
        size = min(c[2], c[3])
        image_font = ImageFont.truetype(FONT_PATH, size)
        im_draw.text((box[0], box[1]), char, font=image_font, fill='#FF0000')
        im_draw.rectangle(box, outline='#0000FF')

testing_img.show()
output_img.show()

for rc in recogs:
    print('[', end='')
    for c in rc:
        print('  %s %.2f  ' % c, end='')
    print(']')
