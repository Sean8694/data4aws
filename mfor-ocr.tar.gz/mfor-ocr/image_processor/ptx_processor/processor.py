import json

import cv2
import image_processor.ptx_processor.sl as sl
import numpy as np
from matplotlib import pyplot as plt
from scipy.ndimage import measurements

import image_processor.ptx_processor.splitutil as splitutil
from common.const import *


# parser = argparse.ArgumentParser()
# parser.add_argument('files',nargs='+')
# args = parser.parse_args()
# files = args.files
# args.files = ocrolib.glob_all(args.files)


def process(file_name):
    # print file_name
    # startTime = time.clock()
    binary = read_image_binary(file_name)
    binary = cv2.convertScaleAbs(binary)
    binary = 1 - binary
    binary = remove_hlines(binary)
    image = cv2.imread(file_name,0)
    filename = file_name.split("/")[-1]
    jsonStr, img, angle,_ = splitutil.compute_skew(binary, image, filename)
    return jsonStr
    # fname = filename.split(".")[0]
    # fp = open('./json/' + fname + '.json', "w")
    # fp.write(jsonStr)
    # fp.close()
    # endTime = time.clock()
    # print(endTime - startTime)


def remove_hlines(binary):
    labels, _ = label(binary)
    objects = find_objects(labels)
    for i, b in enumerate(objects):
        if sl.width(b) > 50:
            labels[b][labels[b] == i + 1] = 0
    return np.array(labels != 0, 'B')


def label(image, **kw):
    """Redefine the scipy.ndimage.measurements.label function to
    work with a wider range of data types.  The default function
    is inconsistent about the data types it accepts on different
    platforms."""
    try:
        return measurements.label(image, **kw)
    except:
        pass
    types = ["int32", "uint32", "int64", "unit64", "int16", "uint16"]
    for t in types:
        try:
            return measurements.label(np.array(image, dtype=t), **kw)
        except:
            pass
    # let it raise the same exception as before
    return measurements.label(image, **kw)


def find_objects(image, **kw):
    """Redefine the scipy.ndimage.measurements.find_objects function to
    work with a wider range of data types.  The default function
    is inconsistent about the data types it accepts on different
    platforms."""
    try:
        return measurements.find_objects(image, **kw)
    except:
        pass
    types = ["int32", "uint32", "int64", "unit64", "int16", "uint16"]
    for t in types:
        try:
            return measurements.find_objects(np.array(image, dtype=t), **kw)
        except:
            pass
    # let it raise the same exception as before
    return measurements.find_objects(image, **kw)


def showImage(original, processed):
    plt.subplot(121), plt.imshow(original, cmap="gray"), plt.title('Input')
    plt.subplot(122), plt.imshow(processed, cmap="gray"), plt.title('Output')
    plt.show()


def read_image_binary(fname, dtype='i', pageno=0):
    if type(fname) == tuple: fname, pageno = fname
    assert pageno == 0
    a = cv2.imread(fname, 0)
    height, width = a.shape
    if height > 3000:
        a = cv2.resize(a, (int(width * 0.5), int(height * 0.5)), cv2.INTER_AREA)
    return np.array(a > 0.5 * (np.amin(a) + np.amax(a)), dtype)


def pil2array(im, alpha=0):
    if im.mode == "L":
        a = np.fromstring(im.tobytes(), 'B')
        a.shape = im.size[1], im.size[0]
        return a
    if im.mode == "RGB":
        a = np.fromstring(im.tobytes(), 'B')
        a.shape = im.size[1], im.size[0], 3
        return a
    if im.mode == "RGBA":
        a = np.fromstring(im.tobytes(), 'B')
        a.shape = im.size[1], im.size[0], 4
        if not alpha: a = a[:, :, :3]
        return a
    return pil2array(im.convert("L"))

def validate(filename):
    fname = filename.split(".")[0]
    print(fname)
    image = cv2.imread('./image_gray/' + fname + '_gray.png' , 0)
    img = image.copy()
    fp = open('./json/' + fname + '.json')
    jsonStr = fp.read()
    fp.close()
    dict = json.loads(jsonStr)
    blocks = dict['blocks']
    for block in blocks:
        x = block['x']
        y = block['y']
        w = block['w']
        h = block['h']
        # cv2.rectangle(img, (x, y), (x + w, y + h), 0)
        char_list = block['chars']
        for char in char_list:
            cv2.rectangle(img, (char[0] + x, char[1] + y), (char[0] + x + char[2], char[1] + y + char[3]), 0)
    showImage(image, img)


if __name__ == '__main__':
    img_path = VALIDATION_DATA_PATH + 'candidate/val_0001.png'
    print(process(img_path))
    # dir = './images'
    # for file in os.listdir(dir):
    #     file_type = os.path.splitext(file)[1]
    #     if file_type == '.jpeg' or file_type == '.jpg' or file_type == '.png':
    #         process(str(dir + '/' + file))
            # validate(file)
