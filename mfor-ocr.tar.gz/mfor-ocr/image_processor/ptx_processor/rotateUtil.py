import cv2
import numpy as np

def rotated(image):
    img = image.copy()
    # try:
    #     img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # except:
    #     img = image.copy()
    try:
        width, height = img.shape
        # edges = cv2.Canny(img, 150, 300, 3, 5)
        lines = cv2.HoughLinesP(img, 1, np.pi/180, 100, minLineLength=width/6, maxLineGap=30)
        angle = 0.0
        number = 0;
        for i in lines:
            for x1, y1, x2, y2 in i:
                tmpAngle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
                if abs(tmpAngle) < 30:
                    angle += tmpAngle
                    number += 1
        angle = angle / number
        m = cv2.getRotationMatrix2D((width/2,height/2), angle, 1)
        image = cv2.warpAffine(image,m,(height,width))
        print(angle)
        return image,angle
    except:
        return image,0
    #
    # img = cv2.bitwise_not(img)
    #
    # non_zero_pixels = cv2.findNonZero(image)
    # center, wh, theta = cv2.minAreaRect(non_zero_pixels)
    #
    # root_mat = cv2.getRotationMatrix2D(center, angle, 1)
    # rows, cols = img.shape
    # rotated = cv2.warpAffine(image, root_mat, (cols, rows), flags=cv2.INTER_CUBIC)
    # image = cv2.getRectSubPix(rotated, (cols, rows), center)
    # return image
    # return cv2.bitwise_not(img)

