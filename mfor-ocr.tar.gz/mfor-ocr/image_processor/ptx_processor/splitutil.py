import json

import cv2

from image_processor.ptx_processor import rotateUtil


def compute_skew(image,src,fname):
    # src = cv2.cvtColor(src,cv2.COLOR_BGR2GRAY)
    image,angle = rotateUtil.rotated(image)
    height,width = src.shape
    m = cv2.getRotationMatrix2D((height / 2, width / 2), angle, 1)
    src = cv2.warpAffine(src, m, (width, height))
    gray = src.copy()
    fname = fname.split(".")[0]
    cv2.imwrite('./image_gray/' +  fname + '_gray.png',src)
    img = image
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 1))
    img = cv2.dilate(img, kernel)
    img, contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE);
    rect_list = []
    # cv2.drawContours(src,contours,-1,0)
    for c in contours:
        rect = cv2.boundingRect(c)
        if rect[2] < 4 and rect[3] < 4:
            continue
        rect_list.append(rect)
        # cv2.rectangle(src, (rect[0], rect[1]), (rect[0] + rect[2], rect[1] + rect[3]), 1)

    rect_list.sort(key=lambda x: (x[1], x[0]))
    blocks = []
    for block in rect_list:
        if block[3] < 5:
            continue
        cropImg = image[block[1]:block[1] + block[3], block[0]:block[0] + block[2]]
        locList = getCharLoc(cropImg, block)
        block_x = block[0] - 1
        block_y = block[1] - 1
        block_w = block[2] + 2
        block_h = block[3] + 2
        dict = {'x':block_x,'y':block_y,'w':block_w,'h':block_h}
        chars = []
        for rect in locList:
            x = rect[0]
            y = rect[1]
            w = rect[2] + 2
            h = rect[3] + 2
            chars.append([x,y,w,h])
        dict['chars'] = chars
        blocks.append(dict)

    dic = {'blocks':blocks}
    jsonStr = json.dumps(dic)
    return jsonStr,image,angle,gray




def getCharLoc(cropImg, outside_rect):
    img, contours, hierarchy = cv2.findContours(cropImg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rect_list = []
    for c in contours:
        rect = cv2.boundingRect(c)
        if rect[2] < 3 and rect[3] < 3:
            continue
        rect = [rect[0], 0, rect[2], outside_rect[3]]
        rect_list.append(rect)
    rect_list = splitSqrt(cropImg, rect_list, outside_rect)
    lenth = len(rect_list)
    if lenth == 0: return [outside_rect]
    if lenth == 1: return [rect_list[0]]
    rect_list.sort(key=lambda x: x[0])
    result = []
    i = 0
    maxWidth = outside_rect[3]

    while i < lenth:
        rect = rect_list[i]
        if rect[2] < 4 and rect[3] < 4:
            i += 1
            continue
        if i + 1 < lenth:
            for k in range(i + 1, lenth):
                nextR = rect_list[k]
                w = rect[2] if (rect[0] + rect[2]) > (nextR[0] + nextR[2]) else (nextR[0] + nextR[2] - rect[0])
                if ((rect[0] + rect[2]) < nextR[0]):
                    break
                if (w > maxWidth):
                    break
                y = rect[1] if rect[1] < nextR[1] else nextR[1]
                h = (rect[1] + rect[3] - y) if (rect[1] + rect[3]) > (nextR[1] + nextR[3]) else (
                    nextR[1] + nextR[3] - y)
                rect = [rect[0], y, w, h]
                i = k
        result.append(rect)
        i += 1
    return result


def splitSqrt(image, rect_list, outside_rect):
    list2 = []
    nRect_list = []
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 3))
    for rect in rect_list:
        if rect[2] > rect[3] * 1.5:
            list2.append(rect)
            img = image[rect[1]:rect[1] + rect[3], rect[0]:rect[0] + rect[2]]
            opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
            _, contours, hierarchy = cv2.findContours(opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                sub_rect = cv2.boundingRect(c)
                sub_rect = [sub_rect[0] + rect[0], 0, sub_rect[2], outside_rect[3]]
                nRect_list.append(sub_rect)
    for r in list2:
        rect_list.remove(r)
    rect_list += nRect_list
    return rect_list


# def showImage(original, processed):
#     plt.subplot(121), plt.imshow(original, cmap="gray"), plt.title('Input')
#     plt.subplot(122), plt.imshow(processed, cmap="gray"), plt.title('Output')
#     plt.show()
#
#
# def showImage2(original):
#     plt.subplot(121), plt.imshow(original, cmap="gray"), plt.title('Input')
#     plt.show()
