# -*- coding: utf-8 -*-
from PIL import Image
from common.const import *
from math import ceil, floor
from aip import AipOcr


class ImageProcessor(object):
    APP_ID = '9301045'
    API_KEY = 'fGnviX7YX891xdT5krggamWs'
    SECRET_KEY = 'c6Nfp2HyyYhDxBtnR0ytBwvBqvq8a60E'

    def __init__(self):
        self.apiOcr = None

    def normalize_image(self, image):
        width = image.size[0]
        height = image.size[1]
        size = (ceil(STANDARD_FONT_SIZE * width / max(width, height)),
                ceil(STANDARD_FONT_SIZE * height / max(width, height)))

        img_resized = image.resize(size, Image.ANTIALIAS)
        img_normalized = Image.new('L', (STANDARD_FONT_SIZE, STANDARD_FONT_SIZE), color=255)
        img_normalized.paste(img_resized, box=(floor((STANDARD_FONT_SIZE - size[0]) / 2), floor((STANDARD_FONT_SIZE - size[1]) / 2)))
        return img_normalized

    def baidu_ocr(self, image_path):
        if not os.path.exists(image_path):
            return None
        if self.apiOcr is None:
            self.aipOcr = AipOcr(self.APP_ID, self.API_KEY, self.SECRET_KEY)
        result = self.aipOcr.general(open(image_path, 'rb').read(), {'recognize_granularity': 'small'})
        return result

    def ptx_ocr(self, image_path):
        pass
