# -*- coding: utf-8 -*-
import os


_cur_path = os.path.split(os.path.realpath(__file__))[0]
_par_path = '/'.join(_cur_path.split('/')[0:-1])

DATA_PATH = _par_path + '/data/'
FONT_PATH = DATA_PATH + 'Songti.ttc'
CHAR_PATH = DATA_PATH + '3500_chars.txt'
SYMBOL_PATH = DATA_PATH + 'symbol.txt'
CHAR_FREQ_PATH = DATA_PATH + 'char_freq.json'

TRAINING_DATA_PATH = _par_path + '/training_data/'

MODEL_DATA_PATH = _par_path + '/model_data/'
MODEL_ARCH_PATH = MODEL_DATA_PATH + 'model_architecture.json'
MODEL_WEIGHTS_PATH = MODEL_DATA_PATH + 'model_weights.h5'

TESTING_DATA_PATH = _par_path + '/testing_data/'

VALIDATION_DATA_PATH = _par_path + '/validation_data/'

STANDARD_FONT_SIZE = 28

TRAINING_CHAR_SET_MIN = 40
TRAINING_CHAR_SET_SIZE = 100

TRAINING_CHAR_SET_MAX_BATCH = 200
