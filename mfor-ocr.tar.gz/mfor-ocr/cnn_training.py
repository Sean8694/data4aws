# -*- coding: utf-8 -*-
from __future__ import print_function
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K
import numpy
from keras.models import model_from_json
from common.const import *
import os


# CONST
BATCH_SIZE = 128
NUM_CLASSES = 3501
EPOCHS = 12

IMG_ROWS, IMG_COLS = STANDARD_FONT_SIZE, STANDARD_FONT_SIZE


# LOAD MODEL
if os.path.exists(MODEL_ARCH_PATH):
    model = model_from_json(open(MODEL_ARCH_PATH).read())
    model.load_weights(MODEL_WEIGHTS_PATH)
else:
    if K.image_data_format() == 'channels_first':
        input_shape = (1, IMG_ROWS, IMG_COLS)
    else:
        input_shape = (IMG_ROWS, IMG_COLS, 1)
    model = Sequential()
    model.add(Conv2D(32, kernel_size=(5, 5), activation='relu', input_shape=input_shape))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.5))
    model.add(Conv2D(512, (5, 5), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.5))
    model.add(Flatten())
    model.add(Dense(4096, activation='relu'))
    model.add(Dense(NUM_CLASSES, activation='softmax'))

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adadelta(),
              metrics=['accuracy'])
print(model.summary())


# TRAINING
rnd = 0

while os.path.exists(TRAINING_DATA_PATH + 'x_%04d.npy' % rnd):
    print('Round: %d' % rnd)
    x_train = numpy.load(TRAINING_DATA_PATH + 'x_%04d.npy' % rnd)
    y_train = numpy.load(TRAINING_DATA_PATH + 'y_%04d.npy' % rnd)

    indices = numpy.arange(len(y_train))
    numpy.random.shuffle(indices)
    x_train = x_train[indices]
    y_train = y_train[indices]

    x_test = numpy.load(VALIDATION_DATA_PATH + 'x.npy')
    y_test = numpy.load(VALIDATION_DATA_PATH + 'y.npy')
    # split_at = len(x_train) - len(x_train) // 5
    # (x_train, x_test) = x_train[:split_at], x_train[split_at:]
    # (y_train, y_test) = y_train[:split_at], y_train[split_at:]

    indices = numpy.arange(len(y_test))
    numpy.random.shuffle(indices)
    x_test = x_test[indices]
    y_test = y_test[indices]

    if K.image_data_format() == 'channels_first':
        x_train = x_train.reshape(x_train.shape[0], 1, IMG_ROWS, IMG_COLS)
        x_test = x_test.reshape(x_test.shape[0], 1, IMG_ROWS, IMG_COLS)
        input_shape = (1, IMG_ROWS, IMG_COLS)
    else:
        x_train = x_train.reshape(x_train.shape[0], IMG_ROWS, IMG_COLS, 1)
        x_test = x_test.reshape(x_test.shape[0], IMG_ROWS, IMG_COLS, 1)
        input_shape = (IMG_ROWS, IMG_COLS, 1)

    x_train = x_train.astype('float32')
    x_test = x_test.astype('float32')
    x_train /= 255
    x_test /= 255
    print('x_train shape:', x_train.shape)
    print(x_train.shape[0], 'train samples')
    print(x_test.shape[0], 'test samples')

    # convert class vectors to binary class matrices
    y_train = keras.utils.to_categorical(y_train, NUM_CLASSES)
    y_test = keras.utils.to_categorical(y_test, NUM_CLASSES)

    model.fit(x_train, y_train,
              batch_size=BATCH_SIZE,
              epochs=EPOCHS,
              verbose=1,
              validation_data=(x_test, y_test))
    score = model.evaluate(x_test, y_test, verbose=0)
    print('Test loss:', score[0])
    print('Test accuracy:', score[1])

    json_string = model.to_json()
    open(MODEL_ARCH_PATH, 'w').write(json_string)
    model.save_weights(MODEL_WEIGHTS_PATH)
    model.save_weights(MODEL_WEIGHTS_PATH + '_%04d' % rnd)

    rnd += 1
